#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <ESP32Servo.h>
const int NUM_SLOTS = 3;
const int slotPin[NUM_SLOTS]  = {13, 14, 27};  
const int greenLed[NUM_SLOTS] = {25, 26, 32};
const int redLed[NUM_SLOTS]   = {33, 18, 19};
const int TRIG_PIN  = 17;
const int ECHO_PIN  = 16;
const int SERVO_PIN = 23;
const int  DETECT_DISTANCE_CM = 20;
const unsigned long CLOSE_DELAY = 2000;  
const int  GATE_OPEN_ANGLE   = 90;
const int  GATE_CLOSED_ANGLE = 0;
LiquidCrystal_I2C lcd(0x27, 16, 2);
Servo gate;
bool gateOpen = false;
unsigned long lastCarSeen = 0;
int lastFreeCount = -1;
bool lastFullState = false;
long readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if (duration == 0) return 999;
  return duration * 0.0343 / 2;
}
int updateSlots() {
  int freeCount = 0;
  for (int i = 0; i < NUM_SLOTS; i++) {
    bool occupied = (digitalRead(slotPin[i]) == LOW);
    digitalWrite(redLed[i],   occupied ? HIGH : LOW);
    digitalWrite(greenLed[i], occupied ? LOW  : HIGH);
    if (!occupied) freeCount++;
  }
  return freeCount;
}
void updateDisplay(int freeCount) {
  bool full = (freeCount == 0);
  if (freeCount == lastFreeCount && full == lastFullState) return;
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("SMART PARKING");
  lcd.setCursor(0, 1);
  if (full) {
    lcd.print("PARKING FULL!");
  } else {
    lcd.print("Free: ");
    lcd.print(freeCount);
    lcd.print("/");
    lcd.print(NUM_SLOTS);
  }
  lastFreeCount = freeCount;
  lastFullState = full;
}
void openGate()  { gate.write(GATE_OPEN_ANGLE);   gateOpen = true;  }
void closeGate() { gate.write(GATE_CLOSED_ANGLE); gateOpen = false; }
void setup() {
  Serial.begin(115200);
  for (int i = 0; i < NUM_SLOTS; i++) {
    pinMode(slotPin[i], INPUT_PULLUP);
    pinMode(greenLed[i], OUTPUT);
    pinMode(redLed[i], OUTPUT);
  }
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  gate.setPeriodHertz(50);
  gate.attach(SERVO_PIN, 500, 2400);
  closeGate();
  Wire.begin(21, 22);   // SDA, SCL
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Smart Parking");
  lcd.setCursor(0, 1);
  lcd.print("Starting...");
  delay(1500);
}
void loop() {
  int freeCount = updateSlots();
  updateDisplay(freeCount);
  long distance = readDistanceCm();
  bool carAtGate = (distance < DETECT_DISTANCE_CM);
  if (carAtGate) {
    lastCarSeen = millis();
    if (!gateOpen && freeCount > 0) {
      openGate();
      Serial.println("Car detected: gate OPEN");
    }
  }

  if (gateOpen && !carAtGate && (millis() - lastCarSeen > CLOSE_DELAY)) {
    closeGate();
    Serial.println("Gate CLOSED");
  }

  if (gateOpen && freeCount == 0 && !carAtGate) {
    closeGate();
  }

  delay(100);
}
